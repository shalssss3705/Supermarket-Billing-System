


public class Main {
    public static void main(String[] args){
        SuperMarket superMarket = new SuperMarket();
        superMarket.run();
    }
}
